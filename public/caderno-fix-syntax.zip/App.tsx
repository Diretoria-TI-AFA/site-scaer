import React, { useState, useEffect, useRef } from 'react';
import { 
  Book, 
  Plus, 
  Trash2, 
  Save, 
  FileText, 
  GraduationCap, 
  BrainCircuit, 
  Bell, 
  Download,
  Search,
  ChevronRight,
  ChevronLeft,
  Sparkles,
  X,
  Send,
  Type,
  Palette,
  Image as ImageIcon,
  Highlighter,
  Bold,
  Italic,
  Underline as UnderlineIcon,
  Link,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  List,
  ListOrdered,
  CheckSquare,
  Subscript as SubscriptIcon,
  Superscript as SuperscriptIcon,
  Quote,
  Heading1,
  Heading2,
  Heading3,
  Eraser,
  Undo,
  Redo,
  Subscript as SubIcon,
  Superscript as SupIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format, differenceInDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import Markdown from 'react-markdown';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Highlight from '@tiptap/extension-highlight';
import { TextStyle } from '@tiptap/extension-text-style';
import { Color } from '@tiptap/extension-color';
import FontFamily from '@tiptap/extension-font-family';
import Image from '@tiptap/extension-image';
import Underline from '@tiptap/extension-underline';
import TextAlign from '@tiptap/extension-text-align';
import Subscript from '@tiptap/extension-subscript';
import Superscript from '@tiptap/extension-superscript';
import TaskList from '@tiptap/extension-task-list';
import TaskItem from '@tiptap/extension-task-item';
import Placeholder from '@tiptap/extension-placeholder';
import { Extension } from '@tiptap/core';

const FontSize = Extension.create({
  name: 'fontSize',
  addOptions() {
    return {
      types: ['textStyle'],
    };
  },
  addGlobalAttributes() {
    return [
      {
        types: this.options.types,
        attributes: {
          fontSize: {
            default: null,
            parseHTML: element => element.style.fontSize.replace(/['"]+/g, ''),
            renderHTML: attributes => {
              if (!attributes.fontSize) {
                return {};
              }
              return {
                style: `font-size: ${attributes.fontSize}`,
              };
            },
          },
        },
      },
    ];
  },
  addCommands() {
    return {
      setFontSize: (fontSize: string) => ({ chain }: any) => {
        return chain()
          .setMark('textStyle', { fontSize })
          .run();
      },
      unsetFontSize: () => ({ chain }: any) => {
        return chain()
          .setMark('textStyle', { fontSize: null })
          .removeEmptyTextStyle()
          .run();
      },
    };
  },
});

import { cn } from './lib/utils';
import { Subject, Note, Assessment, Flashcard } from './types';
import { askAI, generateFlashcards } from './services/ai';

const STORAGE_KEY = 'caderno_virtual_data';

export default function App() {
  // State
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [activeSubjectId, setActiveSubjectId] = useState<string | null>(null);
  const [activeNoteId, setActiveNoteId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'notes' | 'grades' | 'ai' | 'flashcards'>('notes');
  
  // AI State
  const [aiChat, setAiChat] = useState<{ role: 'user' | 'ai', text: string }[]>([]);
  const [aiInput, setAiInput] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [flashcards, setFlashcards] = useState<Flashcard[]>([]);

  // Modal State
  const [isSubjectModalOpen, setIsSubjectModalOpen] = useState(false);
  const [newSubjectName, setNewSubjectName] = useState('');
  const [isNoteModalOpen, setIsNoteModalOpen] = useState(false);
  const [newNoteTitle, setNewNoteTitle] = useState('');

  // Assessment modal
  const [isAssessmentModalOpen, setIsAssessmentModalOpen] = useState(false);
  const [assessmentSubjectId, setAssessmentSubjectId] = useState<string | null>(null);
  const [editingAssessment, setEditingAssessment] = useState<any | null>(null);
  const [assessmentForm, setAssessmentForm] = useState({ name: '', grade: '', weight: '' });

  // Flashcard manual modal
  const [isFlashcardModalOpen, setIsFlashcardModalOpen] = useState(false);
  const [flashcardForm, setFlashcardForm] = useState({ question: '', answer: '' });

  // Title font state (persisted per note in localStorage)
  const [titleFont, setTitleFont] = useState<string>('EB Garamond');
  const [showTitleFontPicker, setShowTitleFontPicker] = useState(false);

  // Refs
  const notebookRef = useRef<HTMLDivElement>(null);

  // Load data
  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch('/api/data');
        const data = await res.json();
        setSubjects(data.subjects || []);
        setNotes(data.notes || []);
        setFlashcards(data.flashcards || []);
        if (data.subjects?.length > 0) setActiveSubjectId(data.subjects[0].id);
      } catch (error) {
        console.error("Erro ao carregar dados do servidor:", error);
      }
    };
    fetchData();
  }, []);

  // Load titleFont from localStorage when note changes
  useEffect(() => {
    if (activeNoteId) {
      const saved = localStorage.getItem(`titleFont_${activeNoteId}`);
      setTitleFont(saved || 'EB Garamond');
    }
  }, [activeNoteId]);

  const handleTitleFontChange = (font: string) => {
    setTitleFont(font);
    if (activeNoteId) {
      localStorage.setItem(`titleFont_${activeNoteId}`, font);
    }
    setShowTitleFontPicker(false);
  };

  // ── Notificações de revisão ──────────────────────────────
  useEffect(() => {
    const checkRevisions = () => {
      if (!('Notification' in window)) return;
      if (Notification.permission === 'default') {
        Notification.requestPermission();
        return;
      }
      if (Notification.permission !== 'granted') return;

      const criticalNotes = notes.filter(n => {
        const days = differenceInDays(new Date(), new Date(n.createdAt));
        return days >= 7;
      });

      if (criticalNotes.length > 0) {
        new Notification('📚 Caderno Virtual — Hora de Revisar!', {
          body: `Você tem ${criticalNotes.length} anotaç${criticalNotes.length === 1 ? 'ão' : 'ões'} aguardando revisão.`,
          icon: undefined,
        });
      }
    };

    // Pede permissão logo que o app abre
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }

    // Verifica na inicialização e depois a cada 2 horas
    const timer = setInterval(checkRevisions, 2 * 60 * 60 * 1000);
    const initialCheck = setTimeout(checkRevisions, 3000);

    return () => { clearInterval(timer); clearTimeout(initialCheck); };
  }, [notes]);

  // ── Chave Gemini ─────────────────────────────────────────
  const [geminiKey, setGeminiKey] = useState(() => localStorage.getItem('gemini_api_key') || '');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [geminiKeyInput, setGeminiKeyInput] = useState('');

  const handleSaveGeminiKey = () => {
    localStorage.setItem('gemini_api_key', geminiKeyInput);
    setGeminiKey(geminiKeyInput);
    setIsSettingsOpen(false);
  };

  const handleAddSubject = async () => {
    if (!newSubjectName.trim()) return;
    const newSubject: Subject = {
      id: crypto.randomUUID(),
      name: newSubjectName,
      color: `hsl(${Math.random() * 360}, 70%, 50%)`,
      assessments: []
    };
    
    try {
      const res = await fetch('/api/subjects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newSubject)
      });
      if (!res.ok) throw new Error("Failed to save subject");
      setSubjects([...subjects, newSubject]);
      setActiveSubjectId(newSubject.id);
      setIsSubjectModalOpen(false);
      setNewSubjectName('');
    } catch (error) {
      alert("Erro ao salvar matéria no servidor.");
    }
  };

  const handleAddNote = async () => {
    if (!activeSubjectId) {
      alert("Selecione uma matéria primeiro!");
      return;
    }
    if (!newNoteTitle.trim()) return;

    const newNote: Note = {
      id: crypto.randomUUID(),
      subjectId: activeSubjectId,
      title: newNoteTitle,
      content: '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    try {
      const res = await fetch('/api/notes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newNote)
      });
      if (!res.ok) throw new Error("Failed to save note");
      setNotes([...notes, newNote]);
      setActiveNoteId(newNote.id);
      setActiveTab('notes');
      setIsNoteModalOpen(false);
      setNewNoteTitle('');
    } catch (error) {
      alert("Erro ao salvar nota no servidor.");
    }
  };

  const updateNote = async (id: string, updates: Partial<Note>) => {
    const updatedNotes = notes.map(n => n.id === id ? { ...n, ...updates, updatedAt: new Date().toISOString() } : n);
    setNotes(updatedNotes);
    
    const noteToUpdate = updatedNotes.find(n => n.id === id);
    if (noteToUpdate) {
      try {
        await fetch(`/api/notes/${id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: noteToUpdate.title,
            content: noteToUpdate.content,
            updatedAt: noteToUpdate.updatedAt
          })
        });
      } catch (error) {
        console.error("Erro ao atualizar nota no servidor:", error);
      }
    }
  };

  const deleteNote = async (id: string) => {
    if (confirm('Tem certeza que deseja excluir esta nota?')) {
      try {
        await fetch(`/api/notes/${id}`, { method: 'DELETE' });
        setNotes(notes.filter(n => n.id !== id));
        if (activeNoteId === id) setActiveNoteId(null);
      } catch (error) {
        alert("Erro ao excluir nota no servidor.");
      }
    }
  };

  const openAddAssessment = (subjectId: string) => {
    setAssessmentSubjectId(subjectId);
    setEditingAssessment(null);
    setAssessmentForm({ name: '', grade: '', weight: '' });
    setIsAssessmentModalOpen(true);
  };

  const openEditAssessment = (assessment: any) => {
    setAssessmentSubjectId(assessment.subjectId);
    setEditingAssessment(assessment);
    setAssessmentForm({ name: assessment.name, grade: String(assessment.grade), weight: String(assessment.weight) });
    setIsAssessmentModalOpen(true);
  };

  const handleSaveAssessment = async () => {
    const grade = parseFloat(assessmentForm.grade);
    const weight = parseFloat(assessmentForm.weight);
    if (!assessmentForm.name.trim() || isNaN(grade) || isNaN(weight)) return;

    try {
      if (editingAssessment) {
        await fetch(`/api/assessments/${editingAssessment.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: assessmentForm.name, grade, weight })
        });
        setSubjects(subjects.map(s => ({
          ...s,
          assessments: s.assessments.map(a =>
            a.id === editingAssessment.id ? { ...a, name: assessmentForm.name, grade, weight } : a
          )
        })));
      } else {
        const newA = { id: crypto.randomUUID(), subjectId: assessmentSubjectId!, name: assessmentForm.name, grade, weight, date: new Date().toISOString() };
        await fetch('/api/assessments', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newA)
        });
        setSubjects(subjects.map(s => s.id === assessmentSubjectId ? { ...s, assessments: [...s.assessments, newA] } : s));
      }
      setIsAssessmentModalOpen(false);
    } catch { alert("Erro ao salvar avaliação."); }
  };

  const deleteAssessment = async (subjectId: string, assessmentId: string) => {
    if (!confirm('Excluir esta avaliação?')) return;
    try {
      await fetch(`/api/assessments/${assessmentId}`, { method: 'DELETE' });
      setSubjects(subjects.map(s => s.id === subjectId ? { ...s, assessments: s.assessments.filter(a => a.id !== assessmentId) } : s));
    } catch { alert("Erro ao excluir avaliação."); }
  };

  const handleSaveManualFlashcard = async () => {
    if (!flashcardForm.question.trim() || !flashcardForm.answer.trim() || !activeSubjectId) return;
    const card = { id: crypto.randomUUID(), subjectId: activeSubjectId, question: flashcardForm.question, answer: flashcardForm.answer };
    try {
      await fetch('/api/flashcards', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(card) });
      setFlashcards([...flashcards, card]);
      setFlashcardForm({ question: '', answer: '' });
      setIsFlashcardModalOpen(false);
    } catch { alert("Erro ao salvar flashcard."); }
  };

  const handleExportPDF = async () => {
    if (!notebookRef.current) return;
    try {
      const canvas = await html2canvas(notebookRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff',
        logging: false,
      });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
      let posY = 0;
      const pageHeight = pdf.internal.pageSize.getHeight();
      while (posY < pdfHeight) {
        pdf.addImage(imgData, 'PNG', 0, -posY, pdfWidth, pdfHeight);
        posY += pageHeight;
        if (posY < pdfHeight) pdf.addPage();
      }
      pdf.save(`${activeNote?.title || 'caderno'}.pdf`);
    } catch (e) {
      alert('Erro ao exportar PDF. Tente novamente.');
      console.error(e);
    }
  };

  const handleAiAsk = async () => {
    if (!aiInput.trim()) return;
    const userMsg = aiInput;
    setAiChat(prev => [...prev, { role: 'user', text: userMsg }]);
    setAiInput('');
    setIsAiLoading(true);

    try {
      const context = activeNote?.content || "";
      const response = await askAI(userMsg, context);
      setAiChat(prev => [...prev, { role: 'ai', text: response || "Desculpe, não consegui processar sua dúvida." }]);
    } catch (error) {
      setAiChat(prev => [...prev, { role: 'ai', text: "Erro ao conectar com a IA. Verifique sua internet." }]);
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleGenerateFlashcards = async () => {
    if (!activeNote?.content) return;
    setIsAiLoading(true);
    try {
      const cards = await generateFlashcards(activeNote.content);
      const newCards = cards.map((c: any) => ({
        id: crypto.randomUUID(),
        question: c.pergunta,
        answer: c.resposta,
        subjectId: activeSubjectId!
      }));

      // Save each card to backend
      for (const card of newCards) {
        await fetch('/api/flashcards', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(card)
        });
      }

      setFlashcards([...flashcards, ...newCards]);
      setActiveTab('flashcards');
    } catch (error) {
      alert("Erro ao gerar flashcards.");
    } finally {
      setIsAiLoading(false);
    }
  };

  const deleteFlashcard = async (id: string) => {
    try {
      await fetch(`/api/flashcards/${id}`, { method: 'DELETE' });
      setFlashcards(flashcards.filter(fc => fc.id !== id));
    } catch (error) {
      alert("Erro ao excluir flashcard no servidor.");
    }
  };

  const activeSubject = subjects.find(s => s.id === activeSubjectId);
  const activeNote = notes.find(n => n.id === activeNoteId);
  const filteredNotes = notes.filter(n => n.subjectId === activeSubjectId);

  // Tiptap Editor Setup
  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        heading: { levels: [1, 2, 3] },
      }),
      Underline,
      Highlight.configure({ multicolor: true }),
      TextStyle,
      Color,
      FontFamily,
      Image.configure({
        allowBase64: true,
      }),
      TextAlign.configure({
        types: ['heading', 'paragraph'],
      }),
      Subscript,
      Superscript,
      TaskList,
      TaskItem.configure({
        nested: true,
      }),
      Placeholder.configure({
        placeholder: 'Comece a escrever suas anotações aqui...',
      }),
      FontSize,
    ],
    content: activeNote?.content || '',
    onUpdate: ({ editor }) => {
      if (activeNoteId) {
        updateNote(activeNoteId, { content: editor.getHTML() });
      }
    },
    editorProps: {
      attributes: {
        class: 'focus:outline-none',
      },
    },
  }, [activeNoteId]);

  // Update editor content when active note changes
  useEffect(() => {
    if (editor && activeNote && editor.getHTML() !== activeNote.content) {
      editor.commands.setContent(activeNote.content);
    }
  }, [activeNoteId, editor]);

  const calculateAverage = (subject: Subject) => {
    if (subject.assessments.length === 0) return '0.00';
    const totalWeight = subject.assessments.reduce((acc, a) => acc + a.weight, 0);
    const weightedSum = subject.assessments.reduce((acc, a) => acc + (a.grade * a.weight), 0);
    return (weightedSum / totalWeight).toFixed(2);
  };

  const getRevisionStatus = (note: Note) => {
    const days = differenceInDays(new Date(), new Date(note.createdAt));
    if (days >= 30) return { label: 'Revisão Crítica', color: 'text-red-500' };
    if (days >= 7) return { label: 'Revisão Necessária', color: 'text-orange-500' };
    if (days >= 1) return { label: 'Revisão Recomendada', color: 'text-blue-500' };
    return { label: 'Recente', color: 'text-green-500' };
  };

  return (
    <div className="flex h-screen overflow-hidden bg-[#f4f1ea]">
      {/* Sidebar - Subjects */}
      <aside className="w-64 bg-slate-900 text-white flex flex-col border-r border-slate-800">
        <div className="p-6 border-b border-slate-800 flex items-center gap-3">
          <Book className="text-emerald-400" />
          <h1 className="font-bold text-lg tracking-tight">Meu Caderno</h1>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
            <div className="flex items-center justify-between px-2 mb-4">
              <span className="text-xs font-semibold uppercase tracking-widest text-slate-500">Matérias</span>
              <button onClick={() => setIsSubjectModalOpen(true)} className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-colors">
                <Plus size={16} />
              </button>
            </div>
          
          {subjects.map(s => (
            <div key={s.id} className="group relative">
              <button
                onClick={() => { setActiveSubjectId(s.id); setActiveNoteId(null); }}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all",
                  activeSubjectId === s.id ? "bg-slate-800 text-white shadow-lg" : "text-slate-400 hover:bg-slate-800/50 hover:text-slate-200"
                )}
              >
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: s.color }} />
                <span className="truncate pr-6">{s.name}</span>
              </button>
              <button 
                onClick={async (e) => { 
                  e.stopPropagation(); 
                  if(confirm(`Excluir a matéria "${s.name}" e todas as suas notas?`)) {
                    try {
                      await fetch(`/api/subjects/${s.id}`, { method: 'DELETE' });
                      setSubjects(subjects.filter(sub => sub.id !== s.id));
                      setNotes(notes.filter(n => n.subjectId !== s.id));
                      if (activeSubjectId === s.id) setActiveSubjectId(null);
                    } catch (error) {
                      alert("Erro ao excluir matéria.");
                    }
                  }
                }}
                className="absolute right-2 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 p-1 text-slate-500 hover:text-red-500 transition-all"
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>

        <div className="p-4 border-t border-slate-800">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span>Modo Offline Ativo</span>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative">
        {/* Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 z-10">
          <div className="flex items-center gap-6">
            <nav className="flex items-center bg-slate-100 p-1 rounded-xl">
              <button 
                onClick={() => setActiveTab('notes')}
                className={cn("px-4 py-1.5 rounded-lg text-sm font-medium transition-all", activeTab === 'notes' ? "bg-white shadow-sm text-slate-900" : "text-slate-500 hover:text-slate-700")}
              >
                Notas
              </button>
              <button 
                onClick={() => setActiveTab('grades')}
                className={cn("px-4 py-1.5 rounded-lg text-sm font-medium transition-all", activeTab === 'grades' ? "bg-white shadow-sm text-slate-900" : "text-slate-500 hover:text-slate-700")}
              >
                Desempenho
              </button>
              <button 
                onClick={() => setActiveTab('flashcards')}
                className={cn("px-4 py-1.5 rounded-lg text-sm font-medium transition-all", activeTab === 'flashcards' ? "bg-white shadow-sm text-slate-900" : "text-slate-500 hover:text-slate-700")}
              >
                Flashcards
              </button>
              <button 
                onClick={() => setActiveTab('ai')}
                className={cn("px-4 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-2", activeTab === 'ai' ? "bg-white shadow-sm text-slate-900" : "text-slate-500 hover:text-slate-700")}
              >
                <BrainCircuit size={14} />
                IA
              </button>
            </nav>
          </div>

          <div className="flex items-center gap-4">
            {activeTab === 'notes' && activeNote && (
              <button onClick={handleExportPDF} className="flex items-center gap-2 px-4 py-2 bg-slate-900 text-white rounded-xl text-sm font-medium hover:bg-slate-800 transition-all">
                <Download size={16} />
                Exportar PDF
              </button>
            )}
          </div>
        </header>

        {/* Workspace */}
        <div className="flex-1 flex overflow-hidden">
          {/* Notes List (if in notes tab) */}
          {activeTab === 'notes' && (
            <div className="w-72 border-r border-slate-200 bg-white/50 overflow-y-auto">
              <div className="p-4 border-b border-slate-200 flex items-center justify-between">
                <h2 className="font-semibold text-slate-900">Anotações</h2>
                <button onClick={() => setIsNoteModalOpen(true)} className="p-1.5 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600 transition-colors">
                  <Plus size={18} />
                </button>
              </div>
              <div className="p-2 space-y-1">
                {filteredNotes.length === 0 ? (
                  <div className="p-8 text-center text-slate-400 text-sm">
                    Nenhuma nota nesta matéria.
                  </div>
                ) : (
                  filteredNotes.map(n => (
                    <div
                      key={n.id}
                      onClick={() => setActiveNoteId(n.id)}
                      className={cn(
                        "w-full text-left p-3 rounded-xl transition-all group cursor-pointer",
                        activeNoteId === n.id ? "bg-white shadow-md border border-slate-200" : "hover:bg-white/80"
                      )}
                    >
                      <div className="flex justify-between items-start mb-1">
                        <span className="font-medium text-slate-900 truncate pr-4">{n.title}</span>
                        <button 
                          onClick={(e) => { e.stopPropagation(); deleteNote(n.id); }}
                          className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-red-500 transition-all"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                      <div className="text-xs text-slate-500 flex flex-col gap-1">
                        <span>{format(new Date(n.updatedAt), "d 'de' MMMM", { locale: ptBR })}</span>
                        <span className={cn("font-medium", getRevisionStatus(n).color)}>
                          {getRevisionStatus(n).label}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Editor / Content Area */}
          <div className="flex-1 overflow-y-auto bg-[#f4f1ea] flex flex-col items-center">
            <AnimatePresence mode="wait">
              {activeTab === 'notes' && activeNote ? (
                <motion.div 
                  key="editor"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="w-full max-w-5xl p-8"
                >
                  {/* Toolbar compacta */}
                  <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-md px-3 py-1.5 mb-4 border border-slate-200 flex flex-wrap gap-1 items-center rounded-xl shadow-lg">

                    {/* Desfazer / Refazer */}
                    <button onClick={() => editor?.chain().focus().undo().run()} disabled={!editor?.can().undo()} className="p-1.5 rounded-lg hover:bg-slate-100 transition-all disabled:opacity-30" title="Desfazer"><Undo size={15} /></button>
                    <button onClick={() => editor?.chain().focus().redo().run()} disabled={!editor?.can().redo()} className="p-1.5 rounded-lg hover:bg-slate-100 transition-all disabled:opacity-30" title="Refazer"><Redo size={15} /></button>

                    <div className="w-px h-5 bg-slate-200 mx-0.5" />

                    {/* Estilo */}
                    <button onClick={() => editor?.chain().focus().toggleBold().run()} className={cn("p-1.5 rounded-lg hover:bg-slate-100 transition-all font-bold text-sm", editor?.isActive('bold') && "bg-emerald-50 text-emerald-600")} title="Negrito"><Bold size={15} /></button>
                    <button onClick={() => editor?.chain().focus().toggleItalic().run()} className={cn("p-1.5 rounded-lg hover:bg-slate-100 transition-all", editor?.isActive('italic') && "bg-emerald-50 text-emerald-600")} title="Itálico"><Italic size={15} /></button>
                    <button onClick={() => editor?.chain().focus().toggleUnderline().run()} className={cn("p-1.5 rounded-lg hover:bg-slate-100 transition-all", editor?.isActive('underline') && "bg-emerald-50 text-emerald-600")} title="Sublinhado"><UnderlineIcon size={15} /></button>
                    <button onClick={() => editor?.chain().focus().toggleSubscript().run()} className={cn("p-1.5 rounded-lg hover:bg-slate-100 transition-all", editor?.isActive('subscript') && "bg-emerald-50 text-emerald-600")} title="Subscrito"><SubIcon size={13} /></button>
                    <button onClick={() => editor?.chain().focus().toggleSuperscript().run()} className={cn("p-1.5 rounded-lg hover:bg-slate-100 transition-all", editor?.isActive('superscript') && "bg-emerald-50 text-emerald-600")} title="Sobrescrito"><SupIcon size={13} /></button>

                    <div className="w-px h-5 bg-slate-200 mx-0.5" />

                    {/* Títulos */}
                    <button onClick={() => editor?.chain().focus().toggleHeading({ level: 1 }).run()} className={cn("p-1.5 rounded-lg hover:bg-slate-100 transition-all", editor?.isActive('heading', { level: 1 }) && "bg-emerald-50 text-emerald-600")} title="Título 1"><Heading1 size={15} /></button>
                    <button onClick={() => editor?.chain().focus().toggleHeading({ level: 2 }).run()} className={cn("p-1.5 rounded-lg hover:bg-slate-100 transition-all", editor?.isActive('heading', { level: 2 }) && "bg-emerald-50 text-emerald-600")} title="Título 2"><Heading2 size={15} /></button>
                    <button onClick={() => editor?.chain().focus().toggleHeading({ level: 3 }).run()} className={cn("p-1.5 rounded-lg hover:bg-slate-100 transition-all", editor?.isActive('heading', { level: 3 }) && "bg-emerald-50 text-emerald-600")} title="Título 3"><Heading3 size={15} /></button>

                    <div className="w-px h-5 bg-slate-200 mx-0.5" />

                    {/* Alinhamento */}
                    <button onClick={() => editor?.chain().focus().setTextAlign('left').run()} className={cn("p-1.5 rounded-lg hover:bg-slate-100 transition-all", editor?.isActive({ textAlign: 'left' }) && "bg-emerald-50 text-emerald-600")} title="Esquerda"><AlignLeft size={15} /></button>
                    <button onClick={() => editor?.chain().focus().setTextAlign('center').run()} className={cn("p-1.5 rounded-lg hover:bg-slate-100 transition-all", editor?.isActive({ textAlign: 'center' }) && "bg-emerald-50 text-emerald-600")} title="Centro"><AlignCenter size={15} /></button>
                    <button onClick={() => editor?.chain().focus().setTextAlign('right').run()} className={cn("p-1.5 rounded-lg hover:bg-slate-100 transition-all", editor?.isActive({ textAlign: 'right' }) && "bg-emerald-50 text-emerald-600")} title="Direita"><AlignRight size={15} /></button>
                    <button onClick={() => editor?.chain().focus().setTextAlign('justify').run()} className={cn("p-1.5 rounded-lg hover:bg-slate-100 transition-all", editor?.isActive({ textAlign: 'justify' }) && "bg-emerald-50 text-emerald-600")} title="Justificar"><AlignJustify size={15} /></button>

                    <div className="w-px h-5 bg-slate-200 mx-0.5" />

                    {/* Listas */}
                    <button onClick={() => editor?.chain().focus().toggleBulletList().run()} className={cn("p-1.5 rounded-lg hover:bg-slate-100 transition-all", editor?.isActive('bulletList') && "bg-emerald-50 text-emerald-600")} title="Lista"><List size={15} /></button>
                    <button onClick={() => editor?.chain().focus().toggleOrderedList().run()} className={cn("p-1.5 rounded-lg hover:bg-slate-100 transition-all", editor?.isActive('orderedList') && "bg-emerald-50 text-emerald-600")} title="Lista Numerada"><ListOrdered size={15} /></button>
                    <button onClick={() => editor?.chain().focus().toggleTaskList().run()} className={cn("p-1.5 rounded-lg hover:bg-slate-100 transition-all", editor?.isActive('taskList') && "bg-emerald-50 text-emerald-600")} title="Checklist"><CheckSquare size={15} /></button>
                    <button onClick={() => editor?.chain().focus().toggleBlockquote().run()} className={cn("p-1.5 rounded-lg hover:bg-slate-100 transition-all", editor?.isActive('blockquote') && "bg-emerald-50 text-emerald-600")} title="Citação"><Quote size={15} /></button>

                    <div className="w-px h-5 bg-slate-200 mx-0.5" />

                    {/* Fonte + Tamanho (3 opções) */}
                    <select
                      onChange={(e) => editor?.chain().focus().setFontFamily(e.target.value).run()}
                      className="bg-slate-50 text-xs border border-slate-200 rounded-lg px-1.5 py-1 focus:ring-1 focus:ring-emerald-400 cursor-pointer text-slate-700 max-w-[110px]"
                      value={editor?.getAttributes('textStyle').fontFamily || 'EB Garamond'}
                      title="Fonte"
                    >
                      <option value="EB Garamond">Garamond</option>
                      <option value="Inter">Sans-Serif</option>
                      <option value="Playfair Display">Playfair</option>
                      <option value="JetBrains Mono">Mono</option>
                      <option value="Caveat">Caveat</option>
                      <option value="Dancing Script">Dancing</option>
                      <option value="Patrick Hand">Patrick</option>
                      <option value="Indie Flower">Indie Flower</option>
                    </select>

                    {/* Apenas 3 tamanhos — Pequeno / Normal / Grande */}
                    <div className="flex items-center bg-slate-50 border border-slate-200 rounded-lg overflow-hidden">
                      {[{label:'P', size:'14px', title:'Pequeno'},{label:'N', size:'18px', title:'Normal'},{label:'G', size:'24px', title:'Grande'}].map(({label, size, title}) => (
                        <button
                          key={size}
                          onClick={() => (editor?.chain().focus() as any).setFontSize(size).run()}
                          className={cn("px-2 py-1 text-xs font-semibold transition-all hover:bg-slate-200", (editor?.getAttributes('textStyle').fontSize === size || (!editor?.getAttributes('textStyle').fontSize && size === '18px')) && "bg-emerald-500 text-white")}
                          title={title}
                        >{label}</button>
                      ))}
                    </div>

                    <div className="w-px h-5 bg-slate-200 mx-0.5" />

                    {/* Cor + Marca-texto */}
                    <div className="relative">
                      <Palette size={13} className="absolute left-1.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none z-10" />
                      <input type="color" onInput={(e) => editor?.chain().focus().setColor((e.target as HTMLInputElement).value).run()} value={editor?.getAttributes('textStyle').color || '#000000'} className="w-10 h-7 pl-5 pr-0.5 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer" title="Cor do texto" />
                    </div>
                    <button onClick={() => editor?.chain().focus().toggleHighlight({ color: '#fef08a' }).run()} className={cn("p-1.5 rounded-lg hover:bg-slate-100 transition-all", editor?.isActive('highlight') && "bg-yellow-200 text-yellow-800")} title="Marca-texto"><Highlighter size={15} /></button>

                    <div className="w-px h-5 bg-slate-200 mx-0.5" />

                    {/* Imagem + Limpar */}
                    <label className="p-1.5 rounded-lg hover:bg-slate-100 transition-all cursor-pointer" title="Inserir imagem">
                      <ImageIcon size={15} />
                      <input type="file" accept="image/*" className="hidden" onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) { const reader = new FileReader(); reader.onload = (ev) => { editor?.chain().focus().setImage({ src: ev.target?.result as string }).run(); }; reader.readAsDataURL(file); }
                      }} />
                    </label>
                    <button onClick={() => editor?.chain().focus().unsetAllMarks().clearNodes().run()} className="p-1.5 rounded-lg hover:bg-slate-100 text-red-400 transition-all" title="Limpar formatação"><Eraser size={15} /></button>
                  </div>

                  <div ref={notebookRef} className="notebook-page rounded-sm">
                    <NotebookLines pageRef={notebookRef} />

                    <div className="notebook-margin">
                      {/* Título — 72px = 2 × 36px de grade */}
                      <div className="notebook-title-wrap">
                        <input
                          type="text"
                          value={activeNote.title}
                          onChange={(e) => updateNote(activeNote.id, { title: e.target.value })}
                          className="notebook-title-input"
                          style={{ fontFamily: titleFont }}
                          placeholder="Título da aula"
                        />
                        <div className="relative flex-shrink-0 self-center ml-2">
                          <button
                            onClick={() => setShowTitleFontPicker(v => !v)}
                            className="p-1.5 text-slate-300 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-all"
                            title="Fonte do título"
                          >
                            <Type size={14} />
                          </button>
                          {showTitleFontPicker && (
                            <div className="absolute right-0 top-9 z-50 bg-white shadow-xl border border-slate-200 rounded-2xl p-2 w-44 space-y-0.5">
                              <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest px-2 pb-1">Fonte do Título</p>
                              {[
                                { label: 'Garamond', value: 'EB Garamond' },
                                { label: 'Playfair', value: 'Playfair Display' },
                                { label: 'Sans-Serif', value: 'Inter' },
                                { label: 'Caveat', value: 'Caveat' },
                                { label: 'Dancing Script', value: 'Dancing Script' },
                                { label: 'Patrick Hand', value: 'Patrick Hand' },
                                { label: 'Indie Flower', value: 'Indie Flower' },
                                { label: 'Mono', value: 'JetBrains Mono' },
                              ].map(f => (
                                <button
                                  key={f.value}
                                  onClick={() => handleTitleFontChange(f.value)}
                                  className={cn(
                                    "w-full text-left px-2 py-1.5 rounded-lg text-sm transition-all hover:bg-slate-50",
                                    titleFont === f.value ? "bg-emerald-50 text-emerald-700 font-semibold" : "text-slate-700"
                                  )}
                                  style={{ fontFamily: f.value }}
                                >
                                  {f.label}
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>

                      <EditorContent editor={editor} />
                    </div>
                  </div>
                </motion.div>
              ) : activeTab === 'grades' ? (
                <motion.div key="grades" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="w-full max-w-5xl p-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {subjects.map(s => {
                      const avg = parseFloat(calculateAverage(s));
                      const totalWeight = s.assessments.reduce((acc, a) => acc + a.weight, 0);
                      return (
                        <div key={s.id} className="bg-white p-5 rounded-3xl shadow-sm border border-slate-100 flex flex-col gap-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: s.color }} />
                              <h3 className="font-bold text-slate-900">{s.name}</h3>
                            </div>
                            <button onClick={() => openAddAssessment(s.id)} className="p-1.5 bg-emerald-50 rounded-lg hover:bg-emerald-100 text-emerald-600 transition-colors" title="Adicionar avaliação">
                              <Plus size={15} />
                            </button>
                          </div>

                          <div className="space-y-2">
                            {s.assessments.length === 0 ? (
                              <p className="text-sm text-slate-400 italic">Nenhuma avaliação.</p>
                            ) : (
                              s.assessments.map(a => (
                                <div key={a.id} className="group flex justify-between items-center text-sm p-2.5 bg-slate-50 rounded-xl hover:bg-slate-100 transition-colors">
                                  <div className="flex-1 min-w-0">
                                    <p className="font-medium text-slate-800 truncate">{a.name}</p>
                                    <p className="text-xs text-slate-400">Peso {a.weight}</p>
                                  </div>
                                  <div className="flex items-center gap-1.5 ml-2">
                                    <span className={cn("font-bold", a.grade >= 7 ? "text-emerald-600" : "text-red-500")}>{a.grade}</span>
                                    <button onClick={() => openEditAssessment({ ...a, subjectId: s.id })} className="opacity-0 group-hover:opacity-100 p-1 text-slate-300 hover:text-blue-500 transition-all" title="Editar"><Type size={12} /></button>
                                    <button onClick={() => deleteAssessment(s.id, a.id)} className="opacity-0 group-hover:opacity-100 p-1 text-slate-300 hover:text-red-500 transition-all" title="Excluir"><Trash2 size={12} /></button>
                                  </div>
                                </div>
                              ))
                            )}
                          </div>

                          {s.assessments.length > 0 && (
                            <div className="text-[11px] text-slate-400 bg-slate-50 rounded-xl px-3 py-2 font-mono break-all">
                              ({s.assessments.map(a => `${a.grade}×${a.weight}`).join(' + ')}) ÷ {totalWeight}
                            </div>
                          )}

                          <div className="pt-3 border-t border-slate-100 flex justify-between items-center">
                            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Média</span>
                            <span className={cn("text-2xl font-black", avg >= 7 ? "text-emerald-600" : "text-red-600")}>{calculateAverage(s)}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </motion.div>
              ) : activeTab === 'ai' ? (
                <motion.div 
                  key="ai"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="w-full max-w-3xl flex flex-col h-[80vh] bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-200"
                >
                  <div className="p-6 bg-slate-900 text-white flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-emerald-500 rounded-xl">
                        <BrainCircuit size={24} />
                      </div>
                      <div>
                        <h2 className="font-bold">Assistente de Estudos</h2>
                        <p className="text-xs text-slate-400">Powered by Gemini AI</p>
                      </div>
                    </div>
                    {activeNote && (
                      <button 
                        onClick={handleGenerateFlashcards}
                        disabled={isAiLoading}
                        className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-xl text-sm font-medium transition-all disabled:opacity-50"
                      >
                        <Sparkles size={16} className="text-emerald-400" />
                        Gerar Flashcards
                      </button>
                    )}
                  </div>

                  <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50">
                    {aiChat.length === 0 && (
                      <div className="h-full flex flex-col items-center justify-center text-center p-12 space-y-4">
                        <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center">
                          <BrainCircuit size={32} />
                        </div>
                        <div>
                          <h3 className="font-bold text-slate-900">Como posso ajudar hoje?</h3>
                          <p className="text-slate-500 text-sm max-w-xs">
                            Tire dúvidas sobre suas anotações, peça resumos ou gere questões de revisão.
                          </p>
                        </div>
                      </div>
                    )}
                    {aiChat.map((msg, idx) => (
                      <div key={idx} className={cn("flex", msg.role === 'user' ? "justify-end" : "justify-start")}>
                        <div className={cn(
                          "max-w-[80%] p-4 rounded-2xl text-sm shadow-sm",
                          msg.role === 'user' ? "bg-emerald-500 text-white" : "bg-white text-slate-800 border border-slate-200"
                        )}>
                          <Markdown>{msg.text}</Markdown>
                        </div>
                      </div>
                    ))}
                    {isAiLoading && (
                      <div className="flex justify-start">
                        <div className="bg-white p-4 rounded-2xl border border-slate-200 flex gap-2">
                          <div className="w-2 h-2 bg-slate-300 rounded-full animate-bounce" />
                          <div className="w-2 h-2 bg-slate-300 rounded-full animate-bounce [animation-delay:0.2s]" />
                          <div className="w-2 h-2 bg-slate-300 rounded-full animate-bounce [animation-delay:0.4s]" />
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="p-4 bg-white border-t border-slate-200 flex gap-2">
                    <input 
                      type="text" 
                      value={aiInput}
                      onChange={(e) => setAiInput(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleAiAsk()}
                      placeholder="Tire uma dúvida sobre a matéria..."
                      className="flex-1 bg-slate-100 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-emerald-500"
                    />
                    <button 
                      onClick={handleAiAsk}
                      disabled={isAiLoading || !aiInput.trim()}
                      className="p-3 bg-emerald-500 text-white rounded-xl hover:bg-emerald-600 transition-all disabled:opacity-50"
                    >
                      <Send size={20} />
                    </button>
                  </div>
                </motion.div>
              ) : activeTab === 'flashcards' ? (
                <motion.div key="flashcards" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-5xl p-4">
                  <div className="flex justify-between items-center mb-6">
                    <h2 className="font-bold text-slate-900 text-lg">Flashcards</h2>
                    <button onClick={() => setIsFlashcardModalOpen(true)} className="flex items-center gap-2 px-4 py-2 bg-emerald-500 text-white rounded-xl text-sm font-medium hover:bg-emerald-600 transition-all">
                      <Plus size={16} /> Criar Card
                    </button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {flashcards.filter(f => f.subjectId === activeSubjectId).length === 0 ? (
                      <div className="col-span-full flex flex-col items-center justify-center p-16 text-center">
                        <div className="w-16 h-16 bg-slate-100 text-slate-300 rounded-full flex items-center justify-center mb-4"><Sparkles size={32} /></div>
                        <h3 className="font-bold text-slate-900 mb-1">Sem Flashcards</h3>
                        <p className="text-slate-500 text-sm">Crie manualmente ou use a IA para gerar automaticamente.</p>
                      </div>
                    ) : (
                      flashcards.filter(f => f.subjectId === activeSubjectId).map(f => (
                        <FlashcardComponent key={f.id} card={f} onDelete={deleteFlashcard} />
                      ))
                    )}
                  </div>
                </motion.div>
              ) : (
                <div className="flex flex-col items-center justify-center text-center p-20">
                  <div className="w-24 h-24 bg-white rounded-full shadow-inner flex items-center justify-center mb-6">
                    <Book size={48} className="text-slate-200" />
                  </div>
                  <h2 className="text-2xl font-bold text-slate-900 mb-2">Selecione uma matéria ou nota</h2>
                  <p className="text-slate-500 max-w-md">Organize seus estudos criando matérias e anotações pautadas com o poder da IA.</p>
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>

      {/* Modals */}
      <AnimatePresence>
        {isSubjectModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-3xl p-8 w-full max-w-md shadow-2xl"
            >
              <h2 className="text-2xl font-bold text-slate-900 mb-6">Nova Matéria</h2>
              <input 
                autoFocus
                type="text" 
                value={newSubjectName}
                onChange={(e) => setNewSubjectName(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleAddSubject()}
                placeholder="Ex: Matemática, História..."
                className="w-full bg-slate-100 border-none rounded-xl px-4 py-3 mb-6 focus:ring-2 focus:ring-emerald-500"
              />
              <div className="flex gap-3">
                <button 
                  onClick={() => setIsSubjectModalOpen(false)}
                  className="flex-1 px-4 py-3 bg-slate-100 text-slate-600 rounded-xl font-medium hover:bg-slate-200 transition-all"
                >
                  Cancelar
                </button>
                <button 
                  onClick={handleAddSubject}
                  className="flex-1 px-4 py-3 bg-emerald-500 text-white rounded-xl font-medium hover:bg-emerald-600 transition-all"
                >
                  Criar
                </button>
              </div>
            </motion.div>
          </div>
        )}

        {isNoteModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-3xl p-8 w-full max-w-md shadow-2xl"
            >
              <h2 className="text-2xl font-bold text-slate-900 mb-6">Nova Anotação</h2>
              <input 
                autoFocus
                type="text" 
                value={newNoteTitle}
                onChange={(e) => setNewNoteTitle(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleAddNote()}
                placeholder="Título da aula ou assunto..."
                className="w-full bg-slate-100 border-none rounded-xl px-4 py-3 mb-6 focus:ring-2 focus:ring-emerald-500"
              />
              <div className="flex gap-3">
                <button 
                  onClick={() => setIsNoteModalOpen(false)}
                  className="flex-1 px-4 py-3 bg-slate-100 text-slate-600 rounded-xl font-medium hover:bg-slate-200 transition-all"
                >
                  Cancelar
                </button>
                <button 
                  onClick={handleAddNote}
                  className="flex-1 px-4 py-3 bg-emerald-500 text-white rounded-xl font-medium hover:bg-emerald-600 transition-all"
                >
                  Criar
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal: Avaliacao */}
      <AnimatePresence>
        {isAssessmentModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
            <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-3xl p-8 w-full max-w-sm shadow-2xl">
              <h2 className="text-xl font-bold text-slate-900 mb-6">{editingAssessment ? 'Editar Avaliacao' : 'Nova Avaliacao'}</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Nome</label>
                  <input autoFocus type="text" value={assessmentForm.name} onChange={e => setAssessmentForm(f => ({...f, name: e.target.value}))}
                    placeholder="Ex: Prova 1, Trabalho..." className="w-full bg-slate-100 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-emerald-500" />
                </div>
                <div className="flex gap-3">
                  <div className="flex-1">
                    <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Nota (0-10)</label>
                    <input type="number" min="0" max="10" step="0.1" value={assessmentForm.grade} onChange={e => setAssessmentForm(f => ({...f, grade: e.target.value}))}
                      placeholder="Ex: 8.5" className="w-full bg-slate-100 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-emerald-500" />
                  </div>
                  <div className="flex-1">
                    <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Peso</label>
                    <input type="number" min="0.1" step="0.1" value={assessmentForm.weight} onChange={e => setAssessmentForm(f => ({...f, weight: e.target.value}))}
                      placeholder="Ex: 1, 2, 3..." className="w-full bg-slate-100 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-emerald-500" />
                  </div>
                </div>
                {assessmentForm.name && assessmentForm.grade && assessmentForm.weight && (
                  <div className="text-xs text-slate-400 bg-slate-50 rounded-xl px-3 py-2 font-mono">
                    Formula: ({assessmentForm.grade} x {assessmentForm.weight}) / {assessmentForm.weight}
                  </div>
                )}
              </div>
              <div className="flex gap-3 mt-6">
                <button onClick={() => setIsAssessmentModalOpen(false)} className="flex-1 px-4 py-3 bg-slate-100 text-slate-600 rounded-xl font-medium hover:bg-slate-200 transition-all">Cancelar</button>
                <button onClick={handleSaveAssessment} className="flex-1 px-4 py-3 bg-emerald-500 text-white rounded-xl font-medium hover:bg-emerald-600 transition-all">
                  {editingAssessment ? 'Salvar' : 'Adicionar'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal: Flashcard manual */}
      <AnimatePresence>
        {isFlashcardModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
            <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-3xl p-8 w-full max-w-md shadow-2xl">
              <h2 className="text-xl font-bold text-slate-900 mb-6">Novo Flashcard</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Pergunta</label>
                  <textarea autoFocus rows={3} value={flashcardForm.question} onChange={e => setFlashcardForm(f => ({...f, question: e.target.value}))}
                    placeholder="Digite a pergunta..." className="w-full bg-slate-100 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-emerald-500 resize-none" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Resposta</label>
                  <textarea rows={3} value={flashcardForm.answer} onChange={e => setFlashcardForm(f => ({...f, answer: e.target.value}))}
                    placeholder="Digite a resposta..." className="w-full bg-slate-100 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-emerald-500 resize-none" />
                </div>
              </div>
              <div className="flex gap-3 mt-6">
                <button onClick={() => setIsFlashcardModalOpen(false)} className="flex-1 px-4 py-3 bg-slate-100 text-slate-600 rounded-xl font-medium hover:bg-slate-200 transition-all">Cancelar</button>
                <button onClick={handleSaveManualFlashcard} disabled={!flashcardForm.question.trim() || !flashcardForm.answer.trim()} className="flex-1 px-4 py-3 bg-emerald-500 text-white rounded-xl font-medium hover:bg-emerald-600 transition-all disabled:opacity-50">Criar</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// NotebookLines
//
// Mecânica: mede UMA VEZ onde o ProseMirror começa (offsetTop),
// soma o padding-top do editor (13px) para chegar na primeira
// baseline, depois desenha todas as linhas com ESPAÇAMENTO
// FIXO de 36px — mesmo valor do line-height do CSS.
//
// Resultado: linhas nunca mudam de lugar, espaçamento sempre
// igual, e o texto (que tem line-height: 36px) naturalmente
// cai em cada pauta.
// ─────────────────────────────────────────────────────────────
const LINE_SPACING = 36; // deve ser idêntico ao line-height do .ProseMirror no CSS

function NotebookLines({ pageRef }: { pageRef: React.RefObject<HTMLDivElement> }) {
  const [origin, setOrigin] = useState<number | null>(null);
  const [pageHeight, setPageHeight] = useState(1100);

  useEffect(() => {
    const calculate = () => {
      const page = pageRef.current;
      if (!page) return;

      const pm = page.querySelector('.ProseMirror') as HTMLElement | null;
      if (!pm) return;

      // offsetTop = distância do topo do ProseMirror ao topo do page
      // + padding-top do ProseMirror (13px, definido no CSS)
      // + cap-height aproximado para EB Garamond 18px (~13px)
      // = posição da primeira baseline
      const pmTop = pm.offsetTop;
      const firstBaseline = pmTop + 13 + 13; // padding-top + cap-height
      setOrigin(firstBaseline);
      setPageHeight(page.offsetHeight);
    };

    calculate();

    const ro = new ResizeObserver(calculate);
    if (pageRef.current) ro.observe(pageRef.current);
    return () => ro.disconnect();
  }, [pageRef]);

  if (origin === null) return null;

  // Gera posições: da primeira baseline até o fim da página
  const lines: number[] = [];
  for (let y = origin; y < pageHeight - 10; y += LINE_SPACING) {
    lines.push(Math.round(y));
  }
  // Também preenche acima da primeira baseline (área do título)
  for (let y = origin - LINE_SPACING; y > 10; y -= LINE_SPACING) {
    lines.unshift(Math.round(y));
  }

  return (
    <div
      className="absolute inset-0 pointer-events-none overflow-hidden"
      style={{ zIndex: 0 }}
      aria-hidden="true"
    >
      {/* Margem vermelha vertical */}
      <div
        className="absolute top-0 bottom-0"
        style={{
          left: '4rem',
          width: '2px',
          backgroundColor: 'rgba(252, 165, 165, 0.8)',
        }}
      />
      {/* Pautas horizontais — espaçamento fixo, nunca mudam */}
      {lines.map((y, i) => (
        <div
          key={i}
          className="absolute left-0 right-0"
          style={{
            top: `${y}px`,
            height: '1px',
            backgroundColor: 'rgba(147, 197, 253, 0.6)',
          }}
        />
      ))}
    </div>
  );
}

function FlashcardComponent({ card, onDelete }: { card: Flashcard, onDelete: (id: string) => void }) {
  const [isFlipped, setIsFlipped] = useState(false);

  return (
    <div className="h-64 perspective-1000 group">
      <motion.div 
        className="relative w-full h-full transition-all duration-500 preserve-3d cursor-pointer"
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        onClick={() => setIsFlipped(!isFlipped)}
      >
        {/* Front */}
        <div className="absolute inset-0 backface-hidden bg-white p-8 rounded-3xl shadow-md border border-slate-100 flex flex-col items-center justify-center text-center">
          <span className="absolute top-4 left-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">Pergunta</span>
          <p className="text-lg font-medium text-slate-800">{card.question}</p>
          <div className="absolute bottom-4 right-4 flex gap-2">
            <button 
              onClick={(e) => { e.stopPropagation(); onDelete(card.id); }}
              className="p-2 text-slate-300 hover:text-red-500 transition-colors"
            >
              <Trash2 size={16} />
            </button>
          </div>
        </div>

        {/* Back */}
        <div className="absolute inset-0 backface-hidden bg-emerald-500 p-8 rounded-3xl shadow-md flex flex-col items-center justify-center text-center rotate-y-180">
          <span className="absolute top-4 left-4 text-[10px] font-bold uppercase tracking-widest text-white/60">Resposta</span>
          <p className="text-lg font-medium text-white">{card.answer}</p>
        </div>
      </motion.div>
    </div>
  );
}
